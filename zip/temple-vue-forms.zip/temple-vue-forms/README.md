# Temple Vue Forms (Demo)

這是一個簡單的 Vue 3 + Vite 範例專案，用於寺廟活動報名表單的前端原型（目前只包含登入與聯絡我們頁面）。
採用假資料接口（`src/services/mockApi.js`），方便在沒有後端時測試。

## 快速開始

1. 下載並解壓縮專案（已包含於壓縮檔）
2. 在專案資料夾執行：
   ```bash
   npm install
   npm run dev
   ```
3. 開啟瀏覽器：http://localhost:5173

## 目前功能
- 登入頁（測試帳號：admin / password）
- 聯絡我們表單（前端驗證 + 假 API 回應）

## 後續擴充建議
- 新增收據建立、列印、匯入 (CSV)
- 活動報名頁面（複數選項、身分資料、座位/人數限制）
- 將 mockApi 換成實際後端 API（axios/fetch）
